CS9053 Homework 07
Congyue Zhang cz733@students.poly.edu
0486449

[How to compile]
javac ChatServer.java
javac ChatClient.java

[Run Chat with default parameters (host:localhost, port:5678, username:Server/Client)]
java ChatServer


[Run Chat with command-line arguments]
java ChatServer <port> <username>
java ChatClient <host> <port> <username>
